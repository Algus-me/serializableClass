from .serializableClass import SerializableClass

__version__ = '1.0'